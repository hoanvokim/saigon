<?php $this->load->view('template/header') ?>
<!-- Revolution Slider -->
<section class="vimeo-wrapper">
    <iframe src="https://player.vimeo.com/video/270817510?autoplay=1&loop=1&autopause=0&byline=0&title=0"
            frameborder="1" webkitallowfullscreen mozallowfullscreen allowfullscreen allow="autoplay; fullscreen"></iframe>
</section>

<?php $this->load->view('template/footer') ?>
